package lsinf1225.uclove;

import java.util.ArrayList;

/**
 * Write a description of class Album here.
 *
 * @author Groupe P
 * @version 25.04.2016
 */
public class Album
{
    // instance variables - replace the example below with your own
    private ArrayList album;

    /**
     * Constructor for objects of class Album
     */
    public Album(ArrayList album)
    {
        // initialise instance variables
        this.album = album;
    }


}
